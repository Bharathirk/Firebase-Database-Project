package com.orgware.atom.data.response.banner;

import com.google.gson.annotations.SerializedName;

public class BannersItem{

	@SerializedName("link_type")
	private String linkType;

	@SerializedName("image")
	private String image;

	@SerializedName("link_to")
	private String linkTo;

	@SerializedName("status")
	private String status;

	public void setLinkType(String linkType){
		this.linkType = linkType;
	}

	public String getLinkType(){
		return linkType;
	}

	public void setImage(String image){
		this.image = image;
	}

	public String getImage(){
		return image;
	}

	public void setLinkTo(String linkTo){
		this.linkTo = linkTo;
	}

	public String getLinkTo(){
		return linkTo;
	}

	public void setStatus(String status){
		this.status = status;
	}

	public String getStatus(){
		return status;
	}
}