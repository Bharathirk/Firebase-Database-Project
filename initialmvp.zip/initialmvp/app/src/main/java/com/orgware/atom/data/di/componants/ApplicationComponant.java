package com.orgware.atom.data.di.componants;

import android.app.Application;

import com.orgware.atom.data.bus.MainThreadBus;
import com.orgware.atom.data.di.modules.ApplicationModule;
import com.orgware.atom.data.navigator.Navigator;
import com.orgware.atom.helper.filecompress.FileCompress;

import dagger.Component;

@Component(modules = {ApplicationModule.class})
public interface ApplicationComponant {

    Application getApplication();

    Navigator getNavigator();

    MainThreadBus getBus();

    FileCompress getFileCompress();


}
