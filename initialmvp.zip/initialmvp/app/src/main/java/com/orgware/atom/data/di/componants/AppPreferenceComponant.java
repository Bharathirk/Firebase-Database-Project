package com.orgware.atom.data.di.componants;


import com.orgware.atom.app.AppPreference;
import com.orgware.atom.data.di.modules.AppPreferenceModule;

import dagger.Component;

@Component(modules = {AppPreferenceModule.class})
public interface AppPreferenceComponant {

    AppPreference getAppPreference();

}
