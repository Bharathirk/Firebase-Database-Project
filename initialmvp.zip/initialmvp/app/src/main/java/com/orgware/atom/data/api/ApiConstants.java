package com.orgware.atom.data.api;

public class ApiConstants {

    public static final String BASE_URL = "https://znap.app/api/v1/";

    public static final String API_OFFER = "offers";

}
