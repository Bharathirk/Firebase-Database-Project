package com.orgware.atom.app;

public class AppConstants {

    public static final int REQUEST_CAMERA_PICK = 1234;
    public static final int REQUEST_GALLERY_PICK = 2345;
    public static final int REQUEST_DOCUMENT_PICK = 3456;
    public static final int REQUEST_AUDIO_PICK = 4567;

    /*Folder Id*/
    public static final String FOLDER_ID = "folder_id";
    public static final String FOLDER_NAME = "folder_name";

    /*Exceptions*/
    public static final String EXCEPTION_NO_NETWORK_CONNECTION = "No Internet connection";
    public static final String EXCEPTION_REQUEST_TIMEOUT = "Request timed out";
    public static final String API_UNKNOWN_FAILURE_MSG = "Something went wrong";
    public static final String HEADER_BEARER = "Bearer ";
    public static final String API_EMAIL = "email";
    public static final String API_MOBILENUMBER = "mobile";
    public static final String API_NAME = "name";
    public static final String API_OTP = "otp";
    public static final String API_OFFERID = "offer_id";
    public static final String API_USERID = "user_id";
    public static final String API_QUANTITY= "quantity";


    public static final String ZNAP = "Pys";
}
