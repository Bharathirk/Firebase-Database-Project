package com.orgware.atom.data.api;

public interface ApiInterface {


//    @GET(ApiConstants.API_OFFER)
//    Observable<OfferResponse> getOfferList(@Header("Authorization") String authorization);
//
//
//    @POST(ApiConstants.API_SIGNUP)
//    Observable<SingupResponse> getSignup(@Header("Authorization") String authorization,
//                                         @Body HashMap<String, String> hashMap);


}
