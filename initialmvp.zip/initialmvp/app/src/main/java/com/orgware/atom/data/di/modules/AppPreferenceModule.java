package com.orgware.atom.data.di.modules;

import android.content.Context;
import android.support.annotation.NonNull;


import com.orgware.atom.app.AppPreference;

import dagger.Module;
import dagger.Provides;

@Module
public class AppPreferenceModule {

    private Context context;

    public AppPreferenceModule(Context context) {
        this.context = context;
    }

    @Provides
    @NonNull
    AppPreference providesAppPreference() {
        return new AppPreference(context);
    }

}
