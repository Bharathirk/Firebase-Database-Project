package com.orgware.atom.data.di.componants;



import com.orgware.atom.data.di.modules.RepositoryModule;

import dagger.Component;

@Component(modules = {RepositoryModule.class})
public interface RepositoryComponant {

}
