package com.orgware.atom.data.response.banner;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class BannerResponse{

	@SerializedName("message")
	private String message;

	@SerializedName("banners")
	private List<BannersItem> banners;

	@SerializedName("status")
	private String status;

	public void setMessage(String message){
		this.message = message;
	}

	public String getMessage(){
		return message;
	}

	public void setBanners(List<BannersItem> banners){
		this.banners = banners;
	}

	public List<BannersItem> getBanners(){
		return banners;
	}

	public void setStatus(String status){
		this.status = status;
	}

	public String getStatus(){
		return status;
	}
}