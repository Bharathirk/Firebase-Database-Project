package com.orgware.atom.data.di.modules;

import android.app.Application;

import com.orgware.atom.data.bus.MainThreadBus;
import com.orgware.atom.data.navigator.Navigator;
import com.orgware.atom.helper.filecompress.FileCompress;

import dagger.Module;
import dagger.Provides;

@Module
public class ApplicationModule {

    private Application application;

    public ApplicationModule(Application application) {
        this.application = application;
    }

    @Provides
    Application providesApplication() {
        return application;
    }

    @Provides
    Navigator providesNavigator() {
        return new Navigator();
    }

    @Provides
    MainThreadBus providesBus() {
        return new MainThreadBus();
    }

    @Provides
    FileCompress provideFileCompress() {
        return new FileCompress();
    }

}
