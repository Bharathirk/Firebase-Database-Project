package com.orgware.atom.helper.filecompress;


import com.orgware.atom.data.models.FolderDetailItem;

public class ImageSelectionEvent {
    private FolderDetailItem item;



    public ImageSelectionEvent(FolderDetailItem item) {
        this.item = item;

    }

    public FolderDetailItem getItem() {
        return item;
    }


    public void setItem(FolderDetailItem item) {
        this.item = item;
    }
}