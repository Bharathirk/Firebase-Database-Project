package com.orgware.atom.data.navigator;


public class Navigator {
//    public void navigateToHomeActivity(Context context) {
//        context.startActivity(new Intent(context, HomeActivity.class));
//    }



}
