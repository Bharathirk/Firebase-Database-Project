package com.orgware.atom.base;

import android.content.Context;

public interface BaseView {

    /**
     *
     * @return the context from an activity to presenter,if needed
     */
    Context getContext();

}
